package com.example.broadcastreceiver;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private BatteryListener listener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listener = new BatteryListener(this);
        listener.register(new BatteryListener.BatteryStateListener() {
            @Override
            public void onStateChanged() {
                Log.e("zhang", "MainActivity --> onStateChanged--> ");
            }
            @Override
            public void onStateLow() {
                Log.e("zhang", "MainActivity --> onStateLow--> ");
                Toast.makeText(MainActivity.this, "onStateLow", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStateOkay() {
                Log.e("zhang", "MainActivity --> onStateOkay--> ");
                Toast.makeText(MainActivity.this, "onStateOkay", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStatePowerConnected() {
                Log.e("zhang", "MainActivity --> onStatePowerConnected--> ");
                Toast.makeText(MainActivity.this, "onStatePowerConnected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStatePowerDisconnected() {
                Log.e("zhang", "MainActivity --> onStatePowerDisconnected--> ");
                Toast.makeText(MainActivity.this, "onStatePowerDisconnected", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (listener != null) {
            listener.unregister();
        }
        super.onDestroy();
    }
}
